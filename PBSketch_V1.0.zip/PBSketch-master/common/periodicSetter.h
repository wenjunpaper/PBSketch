

#ifndef PBSKETCH_PERIODICPARTSETTER_H
#define PBSKETCH_PERIODICPARTSETTER_H

struct PeriodicSetter{

    double delta_;
    int topK_;

    PeriodicSetter(double _delta, int _topK){

        delta_ = _delta;
        topK_ = _topK;
    }

};

#endif //PBSKETCH_PERIODICPARTSETTER_H
