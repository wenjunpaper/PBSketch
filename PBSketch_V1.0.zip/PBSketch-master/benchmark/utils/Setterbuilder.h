#ifndef PBSKETCH_SETTERBUILDER_H
#define PBSKETCH_SETTERBUILDER_H

#include "common/burstSetter.h"
#include "Baseline/burst/BurstSketchSetter.h"
#include "common/periodicSetter.h"
#include "PBSketch/PartOne/PartOneSetter.h"

class SetterBuilder {
public:
    static BurstSetter getBurstSetter();
    static BurstSetter getAppBurstSetter();

    static PeriodicSetter getPeriodicSetter();
    static PeriodicSetter getAppPeriodicSetter();

    static BurstSketchSetter getBurstSketchSetter();
    static PartOneSetter getPartOneSetter();

    static const int CellNum = 5;
    constexpr static const double rOne = 0.2;
    constexpr static const double BaselineMemoryRate = 0.6;
    constexpr static const double PeriodicSketchMemoryRate = 0.1;


};


#endif //PBSKETCH_SETTERBUILDER_H
