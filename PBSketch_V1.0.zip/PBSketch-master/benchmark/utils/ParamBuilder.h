

#ifndef PBSKETCH_PARAMBUILDER_H
#define PBSKETCH_PARAMBUILDER_H


class ParamBuilder {
public:

    class Param{
    public:

       class Rate{
       public:
           static const int ParamExperimentNum = 6;
           static constexpr double rates[ParamExperimentNum] = {0.2, 0.25, 0.3, 0.4, 0.45, 0.5};
           static const int MemoriesNum = 5;
           static constexpr double memories[MemoriesNum] = {25,50, 75, 100, 125};

       };
        class PThres{
        public:
            static const int ParamExperimentNum = 6;
            static constexpr double params[ParamExperimentNum] = {0,2,4,6,8,10};
            static const int MemoriesNum = 5;
            static constexpr double memories[MemoriesNum] = {25,50, 75, 100, 125};

        };
        class CompressRate{
        public:
            static const int ParamExperimentNum = 6;
            static constexpr double rates[ParamExperimentNum] = { 2.0/32, 3.0/32, 4.0/32, 8.0/32, 12.0/32, 16.0/32};

            static const int MemoriesNum = 5;
            static constexpr double memories[MemoriesNum] = {25, 50, 75, 100, 125};

        };

        class HRate{
        public:
            static const int ParamExperimentNum = 6;
            static constexpr double hRates[ParamExperimentNum] = {0.1, 0.3, 0.5, 0.7, 0.9, 0.95};
            static const int MemoriesNum = 5;
            static constexpr double memories[MemoriesNum] = {25 ,50, 75, 100, 125};

        };
    };

    class Throughput{
    public:
        class CAIDA{
        public:
            static const int ExperimentNum = 5;
            static constexpr double memories[ExperimentNum] = {20, 40, 60, 80, 100};


        };

        class Wave{
        public:
            static const int ExperimentNum = 1;
            static constexpr double memories[ExperimentNum] = {200};


        };
        class Mawi{
        public:
            static const int ExperimentNum = 5;
            static constexpr double memories[ExperimentNum] = {50, 75, 100, 125, 150};

        };

    };
    class Memory{
    public:
        class CAIDA{
        public:
            static const int ExperimentNum = 5;
            static constexpr double memories[ExperimentNum] = {20, 40,60, 80, 100};

        };

        class Mawi{
        public:
            static const int ExperimentNum = 5;
            static constexpr double memories[ExperimentNum] = {50, 75, 100, 125, 150};

        };

    };


};


#endif //PBSKETCH_PARAMBUILDER_H
