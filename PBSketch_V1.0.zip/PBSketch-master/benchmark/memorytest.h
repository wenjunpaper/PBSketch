#ifndef PBSKETCH_MEMORYTEST_H
#define PBSKETCH_MEMORYTEST_H

#include "../common/datasetAnalysis/CAIDADataset.h"
#include <fstream>
#include "benchmark/utils/Comparer.h"
#include "../PBSketch/PBSketch.h"
#include "../PBSketchOpt/PBSketchOpt.h"


class MemoryTest {
public:

    static void run(std::string _datasetPath, int _runLength, int _addHashSeed = 0);
    static void runMawi(std::string _datasetPath, int _runLength);
};


#endif //PBSKETCH_MEMORYTEST_H
