#ifndef PBSKETCH_PARAMTEST_H
#define PBSKETCH_PARAMTEST_H

#include "../common/datasetAnalysis/CAIDADataset.h"
#include <fstream>
#include "benchmark/utils/Comparer.h"
#include "../PBSketch/PBSketch.h"

class ParamTest {
    public:

    static void runRate (std::string _datasetPath, int _runLength);
    static void runPThres (std::string _datasetPath, int _runLength);
    static void runHRate(std::string _datasetPath, int _runLength);
    static void runCompressRate (std::string _datasetPath, int _runLength);

};


#endif //PBSKETCH_PARAMTEST_H
