

#ifndef PBSKETCH_PARTONESETTER_H
#define PBSKETCH_PARTONESETTER_H

#include <cstdint>

struct PartOneSetter{
    int memory_;
    int levelAmount_;
    uint32_t periodThreshold_;
    double upcallRate_ ;
    uint32_t maxTimestamp_;

    PartOneSetter(int _memory, int _levelAmount, uint32_t _periodThreshold, double _upcallRate, uint32_t _maxTimestamp){
        memory_ = _memory;
        levelAmount_ = _levelAmount;
        periodThreshold_ = _periodThreshold;
        upcallRate_ = _upcallRate;
        maxTimestamp_ = _maxTimestamp;
    }
};

#endif //PBSKETCH_PARTONESETTER_H
