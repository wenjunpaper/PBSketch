
#ifndef PBSKETCH_PTWOBUCKET_H
#define PBSKETCH_PTWOBUCKET_H

#include "common/pairutil.h"

struct CellD{
    DATA_TYPE key = 0;
    uint32_t v = 0;
    COUNT_TYPE r = 0;
};

template <uint32_t CELL_NUM>
struct BucketD{
    CellD cells[CELL_NUM];
    int C_fail = 0;
};


#endif //PBSKETCH_PTWOBUCKET_H