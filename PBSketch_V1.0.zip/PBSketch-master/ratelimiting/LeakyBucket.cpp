#include <set>
#include "LeakyBucket.h"

LeakyBucket::LeakyBucket(int _windowSize, int _opNum, int _maxBucketSize):windowSize_(_windowSize), opNUm_(_opNum), maxBucketSize_(_maxBucketSize) {}

void LeakyBucket::insert(uint64_t _key, uint64_t t) {
    if(buckets.find(_key) == buckets.end()){
        buckets[_key] = 1;
    }else{
        if(buckets[_key] < maxBucketSize_){
            buckets[_key]++;
        }else{
            rejectNum_++;
        }
    }

    if(t % windowSize_ == 0){
        windowOperate();
    }
}

void LeakyBucket::windowOperate() {
//    for(auto &iter : buckets){
//        iter.second -= opNUm_;
//        if(iter.second < 0){
//            iter.second = 0;
//        }
//
//    }

    //opt
    auto it = buckets.begin();
    while(it != buckets.end())
    {
        it->second -= opNUm_;
        if(it->second <= 0)
        {
            it = buckets.erase(it);
        }
        else
            it++;
    }
}

